import React from "react";
import { Menu, Dropdown, Button, Space, Row, Col } from "antd";
import { Link } from 'react-router-dom'

function DefaultLayout(props) {
  const user = JSON.parse(localStorage.getItem('user'))
  const menu = (
    <Menu>
      <Menu.Item>
        <a

          href="/"
        >
          Home
        </a>
      </Menu.Item>
      <Menu.Item>
        <a

          href="/userbookings"
        >
          Bookings
        </a>
      </Menu.Item>
      <Menu.Item>
        {/* <a
         
          href="/admin"
        >
          Admin
        </a> */}
      </Menu.Item>
      <Menu.Item onClick={() => {
        localStorage.removeItem('user');
        window.location.href = '/login'
      }}>
        <li style={{ color: 'orangered' }}>Logout</li>
      </Menu.Item>
    </Menu>
  );
  return (
    <div>
      <div className="header bs1">
        <Row gutter={16} justify='center'>
          <Col lg={20} sm={24} xs={24}>
            <div className="d-flex justify-content-between">
              <h1 className="naam"><b><Link to='/' style={{ color: 'orangered'}}>Apni Gaadi</Link></b></h1>

              <Dropdown overlay={menu} placement="bottomCenter">
                <Button className="nam">{user.username}</Button>
              </Dropdown>
            </div>
          </Col>
        </Row>

      </div>
      <div className="content">{props.children}</div>

      <div className="footer text-center">
        <hr />
        <footer class="page-footer font-small blue pt-4">
          <div class="container-fluid text-center text-md-left">
            <div class="row">
              <div class="col-md-6 mt-md-0 mt-3">
                <h5 class="text-uppercase">Apni Gaadi</h5>
                <p>Just rent the Vehicle and letsss broom!!!!.</p>
              </div>
              <hr class="clearfix w-100 d-md-none pb-3" />
              <div class="col-md-3 mb-md-0 mb-3">
                <h5 class="text-uppercase">Links</h5>
                <ul class="list-unstyled">
                  <li>
                    <a href="/">Home</a>
                  </li>
                  <li>
                    <a href="/login">LogIn</a>
                  </li>
                  <li>
                    <a href="/userbookings">MyBookings</a>
                  </li>
                  <li>
                    <a href="/register">Registration</a>
                  </li>
                </ul>
              </div>

            </div>
          </div>
          <div class="footer-copyright text-center py-3">© 2023 Copyright:
            <a href="/">Apni Gaadi.com</a>
          </div>

        </footer>

      </div>
    </div>
  );
}

export default DefaultLayout;
